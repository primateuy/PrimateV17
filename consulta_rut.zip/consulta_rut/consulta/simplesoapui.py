import requests
import os
from dotenv import load_dotenv

load_dotenv()
SOAP_REQUEST = os.getenv('SOAP_REQUEST')

# SOAP request URL
url = "https://serviciosdp.dgi.gub.uy:6491/RUTWSPGetEntidad/servlet/arutpersonagetentidad"

# structured XML
payload = SOAP_REQUEST
# headers
headers = {
	'Content-Type': 'text/xml;charset=UTF-8'
}
# POST request
response = requests.request("POST", url, headers=headers, data=payload)

# prints the response
print(response.text)
print(response)
