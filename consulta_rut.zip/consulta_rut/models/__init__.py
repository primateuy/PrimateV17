# -*- coding: utf-8 -*-

from . import consulta_rut
