import re
from odoo import models, fields, api
import requests
import logging
from odoo.exceptions import ValidationError
import os
from dotenv import load_dotenv
currentdir = os.path.dirname(os.path.realpath(__file__))
env_path = currentdir + "/.env"
load_dotenv(env_path)
ENV_SOAP_REQUEST = os.getenv('SOAP_REQUEST')
_logger = logging.getLogger(__name__)



class RucRequest(models.Model):
    _name = 'ruc.request'
    _description = 'RUC Request Handler'

    ruc = fields.Char(string='RUC', help="Enter RUC here")
    result = fields.Text(string='Result', readonly=True)



    def button_fetch_result(self):
        full_url = "https://serviciosdp.dgi.gub.uy:6491/RUTWSPGetEntidad/servlet/arutpersonagetentidad"
        headers = {
            'Content-Type': 'text/xml;charset=UTF-8'
        }

        SOAP_REQUEST = f'''<soapenv:Envelope xmlns:dgi="DGI_Modernizacion_Consolidado" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header><wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"><wsse:BinarySecurityToken EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary" ValueType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509PKIPathv1" wsu:Id="X509-2D07B42FEB1F8D2BF3170721839203686">MIIUIzCCBp0wggSFoAMCAQICEgLuAJtm2GodZ/7aiiVvIVp1GzANBgkqhkiG9w0BAQsFADBaMTowOAYDVQQDDDFBdXRvcmlkYWQgQ2VydGlmaWNhZG9yYSBSYcOteiBOYWNpb25hbCBkZSBVcnVndWF5MQ8wDQYDVQQKEwZBR0VTSUMxCzAJBgNVBAYTAlVZMB4XDTExMTEwMzE1MDI0OVoXDTMxMTAyOTE1MDI0OVowWjE6MDgGA1UEAwwxQXV0b3JpZGFkIENlcnRpZmljYWRvcmEgUmHDrXogTmFjaW9uYWwgZGUgVXJ1Z3VheTEPMA0GA1UEChMGQUdFU0lDMQswCQYDVQQGEwJVWTCCAiAwDQYJKoZIhvcNAQEBBQADggINADCCAggCggIBAJfEHypEoYFLSJF13evaj8obi/K0PCzG5fTBHtG4MBNvXJ/lUZZ/GqQW/tLUHSX20OY3YF8Aoxmp7Ce/UC0FoFxek+vjaP2bPbkUNi3nJRUQkBqSyRGxKZeTVlVirUesf9UMd5bSk2hqMd1U75PyCk+gXwJa77ZEPueZso5F3qD3wOhIsEfs3kIU2zV7oGn8HsABKRbaM6EhoTIyEHZ9qMfALnODZPxa95s2jGntIFUjec3z82xrYFx4jfw9hSy8qfdw6KXKTdh8mO+GdhiE1UApECcy5+8DRAtPySrxtrQroNUDlIQh03TzKW148AVqrgEPYR/GpfDHghXZO/vdi3Rp7uTHx/QR3BRRwYQaJVYTa1vOXyz9ixstD8jAVaoYT5icz6J3CLQ1ldi5i5xJDrQQC/z8R03Umlf5n3q96Ve7tA9fFZDYaGzVhSWDLYYMR2KXs3lNuWUId1JvSuNugMCso9W86kniZeJMWWqC3iv1qj7+ZehRcE03hAYEP5KD1FYo4yXVVMqF7lbALs75cBASX12exrxLEB1WbcpywVMJKhM92LX5HDtFxocU0Dh+niFf/HYd/wspQtuhxHk54U3VhlDj8uCz11mb3j8eGgPz1GmGS0ccMn88BwkTEKebBzB3M7xpEdE0PXwQKrgejr1H3vmyeVVmIQIH+zksChehAgEDo4IBXTCCAVkwDgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wYgYDVR0fBFswWTAsoCqgKIYmaHR0cDovL3d3dy5hZ2VzaWMuZ3ViLnV5L2Fjcm4vYWNybi5jcmwwKaAnoCWGI2h0dHA6Ly93d3cudWNlLmd1Yi51eS9hY3JuL2Fjcm4uY3JsMIGyBgNVHSAEgaowgacwXAYLYIZahOKuHYSIBQAwTTBLBggrBgEFBQcCARY/aHR0cDovL3d3dy51Y2UuZ3ViLnV5L2luZm9ybWFjaW9uLXRlY25pY2EvcG9saXRpY2FzL2NwX2Fjcm4ucGRmMEcGC2CGWoTirh2EiAUBMDgwNgYIKwYBBQUHAgEWKmh0dHA6Ly93d3cuYWdlc2ljLmd1Yi51eS9hY3JuL2Nwc19hY3JuLnBkZjAdBgNVHQ4EFgQUkp6RuFUoPXdCLDOlmF/QyayNtaMwDQYJKoZIhvcNAQELBQADggIBAF3nq1nqSdy/RkP9lLuYcJQU+s4DXfF9MROSToUkMBRrbNPnzuZ51dtOVU4XK9eTRd8TDCdnHcdCkFQwxvGoaSi0TqZtpTWmUJZoSaPuLwur/AMCUGjxlSk+cSzc2uUt2XYu7lYzfhehJwLhoScoIYq/Aedix7uyJQTaG6YjjHyTusmL6wr5N7eUOf1Nj36i3IFvG60UD1sgA3hBc2ee0pcXkCqKVEuneX8kEpGfOyzHN6QMXHJqE54yCSfrQzJ1X9dHwypFUxVWdk+7CeiEYBHvc9XnUG5pKP3rxsvKThNjDQ43LDEf26dYoLL9DReHs5KuGyiAH7aSfoYR4fZMmH9mix8TSQNC/PuYnO6GlqkuBX5wHMF3yOldgrgOzltkBWPuPwYtNgzpH3JbHqzdJvUcOG79jD1Nhusny8oDjUDzKtGK2DQOwq21iO2HmoqFoofv6bk452iWowHPgj0cSyidJ/X5mZZ7SP2s0PAy9zgE3U2Zrg6SgsP6PBsTx2i3XeCTRri4uKQMxBvGukaW3Z5VD0ed9oGlrGVZ2N2uBmzgQ4LGZ9hwAjX1NgTjSjmpdQIe5j9Gz5wsHoSIF6omqaZDgODAW6Nkg5ua7WsBZbbBPRjskxlmlKjTEVCZeoh9rz5/lJA7CsNqt41f0qdR0TIfufIyfXeTbUPsQWmrz8lhMIIHBjCCBO6gAwIBAgITAKO7+JPCd/2puZWeyprq8jaEhDANBgkqhkiG9w0BAQsFADBaMTowOAYDVQQDDDFBdXRvcmlkYWQgQ2VydGlmaWNhZG9yYSBSYcOteiBOYWNpb25hbCBkZSBVcnVndWF5MQ8wDQYDVQQKEwZBR0VTSUMxCzAJBgNVBAYTAlVZMB4XDTE0MDYyMDE3MjcyNVoXDTMxMTAyNzE3MjcyNVowXjELMAkGA1UEBhMCVVkxEzARBgNVBAcTCk1vbnRldmlkZW8xFDASBgNVBAoTC0FiaXRhYiBTLkEuMRMwEQYDVQQLEwpJRCBkaWdpdGFsMQ8wDQYDVQQDEwZBYml0YWIwggIgMA0GCSqGSIb3DQEBAQUAA4ICDQAwggIIAoICAQDEOrr81JzQXEKytNhlSiuJxd/ca9oXfPmfIJh5RRkHyMpzFm6z1smuCNoVxDmBlxXL+ktXP3eUG2BGQ0f6VynJwsJG9Tc02eOR0Jyqfmi5pO2prTK4TwWrUvPMSu7r4rtybleWWi2IS+VpsEnEP9T34TijbN1MiLMOmKU/Q5sCfAA83gPLD/7Ah9V4IBmqTItTg7aM43y1wsswlrHpo79lEnDqLRTrF69edjMicWLwB4O15VBWebXWd69XTlHJxoIvwNWBGOv/6Zpfw8n9B9dl0xTPxvn2axndE/DnZY0au7XVJvwkX51E8LmiDiCvq70lNIAJqQrdtMGM/+p2lHF5LLgyEJpRjApJssCTOQIZeV02Ox0X1VOKljc1xj0S8e5Fv9+tGq4yVV4d8pnDVZwYsPw/JmooMb5JAmoEohIY2+MetU89jsu3Dw+NY7Qq7TbKr9Dv/kZJt4jmhgXc7C/AwQsXjh6FPrv1OT1MdDkonhn+c+sbXJZgtew69sBjJ0k0gOvf6cwwiT62g1Smak9F0BHCWUsLi9IMMgKGZQ4RNhABFlsXvuBmh3ZxORpv2hTmksqYho6BU+OOyoCEuL6bX02hro1lMIpgg6EkP4s+cQ/7V/leYp4nchQXGvM8X6iAjdQzxMUpwe6quhShFQGor40yJpc+AZcda8P9gRZ6nwIBA6OCAcEwggG9MEIGCCsGAQUFBwEBBDYwNDAyBggrBgEFBQcwAoYmaHR0cDovL3d3dy5hZ2VzaWMuZ3ViLnV5L2Fjcm4vYWNybi5jZXIwDgYDVR0PAQH/BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQAwYgYDVR0fBFswWTApoCegJYYjaHR0cDovL3d3dy51Y2UuZ3ViLnV5L2Fjcm4vYWNybi5jcmwwLKAqoCiGJmh0dHA6Ly93d3cuYWdlc2ljLmd1Yi51eS9hY3JuL2Fjcm4uY3JsMIGuBgNVHSAEgaYwgaMwWgYJYITirh2EiAUAME0wSwYIKwYBBQUHAgEWP2h0dHA6Ly93d3cudWNlLmd1Yi51eS9pbmZvcm1hY2lvbi10ZWNuaWNhL3BvbGl0aWNhcy9jcF9hY3JuLnBkZjBFBglghOKuHYSIBQEwODA2BggrBgEFBQcCARYqaHR0cDovL3d3dy5hZ2VzaWMuZ3ViLnV5L2Fjcm4vY3BzX2Fjcm4ucGRmMB0GA1UdDgQWBBQNE9b2xiim58W3h9EknJ+T8OgdOzAfBgNVHSMEGDAWgBSSnpG4VSg9d0IsM6WYX9DJrI21ozANBgkqhkiG9w0BAQsFAAOCAgEAWwIkaSAVlsYH5zU6/t9QxDPvmuqodJAjhT99trb3qORjc2RtObjErOmlum4Ge95CFIjPQii2koWJopeU9az5lx+P9pWI+9Dp80YlfPoeNbmwYYgVuN5pVpO6cqZRVmPiHaGhRg6JuktcOov7i/3TWglyNCJjvN0VMif2DzA2G75o6Fel2UDxSJvyHOif5Rkbjvrt6IGme5SUfeSSXrXCN0Eu2ClxCKRA5HuLdRiXgzWmpkt9Ge+d3VwQDttVTwxdv5QC+gNvgMZsG5P7lxB2rjSUGRDXJ1Xnq1hmCgLOOrbwm30qe/Ukp9V95F9JEJNCxUkdMgQKQCEUzR2dIcimjeohYmooqwsHdVi7OGsNF6Dqf4jodgJLGf8NHKZA2/bL3NtdN7jlAhnS4SO8f+3l4Pkp+0p1G0kFkSVgEXMuoJzgdecxaFHkyuvnXuQiOQVoleNCw8dHimACyTdfMzTLFppdzcaX3DypxlxvYN8V0SafviBn1iycuDUVWCCmGxD01TFGKuC4ltXLyzU9w+i0hNGcZON8vHJr8Wlz/EmYpVMod2aMLQsqjiNtMXbd5GedHbdT9Yl5zTEolvEOVVAH7dlWsDq0NUJ9hgwJ7mXv2L5flqbgtTIgXD4wXx0DenOWqTkKD6GXqb1vmxWs79h84PJht3tclJyckr6zSEI6u6swggZ0MIIEXKADAgECAhUAmPZkC/msL4NkqQENfkwL/yfA02wwDQYJKoZIhvcNAQELBQAwXjELMAkGA1UEBhMCVVkxEzARBgNVBAcTCk1vbnRldmlkZW8xFDASBgNVBAoTC0FiaXRhYiBTLkEuMRMwEQYDVQQLEwpJRCBkaWdpdGFsMQ8wDQYDVQQDEwZBYml0YWIwHhcNMjMwOTAxMTM1MDQwWhcNMjUwODMxMTM1MDQwWjBmMQswCQYDVQQGEwJVWTETMBEGA1UECBMKTW9udGV2aWRlbzEYMBYGA1UEBRMPUlVDMTgwMzE4MjEwMDE1MRYwFAYDVQQKEw1QcmltYXRldXkgU0FTMRAwDgYDVQQDEwdQcmltYXRlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0MG0Eii/UCqQupkG4TeEHMyXtlTTk2jV6rw+vtICgAKuFT/LSVpA25u1GuYgK//C2Qdg4nEOz842GyDRTVcBxXKFwg8iyp/lEOOowq4FgafLOjgQmj3rLoASsdQrkjK79wWYqH1vc+xpud+4QL1lRmugBYyJUX3zeqHoczsceURjL0X9k30SUahvfXxbRtzi8OVISW2QGKS/JogVWZIMrkp2fZ0pnQMY6cNkTy5uQsltK8vJh1cQ5yOuOsL02TMTnSZuoFmqBZfmhkc09N65oqyX7iZsK299EEs00q9kqV0kgzB3Z4cGrtdudZtzJVBHVAVOk3+eYOtXEO6/zPSe9QIDAQABo4ICHzCCAhswgYAGCCsGAQUFBwEBBHQwcjA1BggrBgEFBQcwAoYpaHR0cDovL3d3dy5pZC5jb20udXkvcmVzb3VyY2VzL0FiaXRhYi5jcnQwOQYIKwYBBQUHMAGGLWh0dHA6Ly9vY3NwLmlkLmNvbS51eS9hc2Yvc2VydmxldC9PQ1NQU2VydmxldDAOBgNVHQ8BAf8EBAMCBPAwDAYDVR0TAQH/BAIwADBOBgNVHR8ERzBFMEOgQaA/hj1odHRwOi8vY3JsLmlkLmNvbS51eS9yZXNvdXJjZXMvY3JsX2lkX2RpZ2l0YWxfcGtpX3VydWd1YXkuY3JsMIHSBgNVHSAEgcowgccwZAYLYIZahOKuHYSIBQQwVTBTBggrBgEFBQcCARZHaHR0cDovL3VjZS5ndWIudXkvaW5mb3JtYWNpb24tdGVjbmljYS9wb2xpdGljYXMvY3BfcGVyc29uYV9qdXJpZGljYS5wZGYwXwYLYIZahOKuHYSIBQcwUDBOBggrBgEFBQcCARZCaHR0cDovL3d3dy5pZC5jb20udXkvcmVzb3VyY2VzL2Nwc19pZF9maXJtYUVsZWN0cm9uaWNhQXZhbnphZGEucGRmMBMGA1UdJQQMMAoGCCsGAQUFBwMCMB0GA1UdDgQWBBQSiqnVkwHFDiXVo/BF/YnR0vdILjAfBgNVHSMEGDAWgBQNE9b2xiim58W3h9EknJ+T8OgdOzANBgkqhkiG9w0BAQsFAAOCAgEAkX4CSXggiR3LXDqUvp+WOHmBMSfn49YyWlLjNDuXdpHWoxefsOy4l6zpixHGTQpK/cDJ7j0Np81GEXp1eWhcx6AprOG7N9MP3/y2bTSTQGhr5BkcFWhiG/nC/+RCiG8ieHMpB/XYuc0EKdV6HQ14MXVEqSQ8zlgF+micB3deWsxsXXfgO8N7tHMIlx+hZU4I08RFUSaqGbM+//BG5p0f+O5MKQm6zZdvmQ6czBccVvCPV14EFw8IoQ2ptsXfY/mh1QLI8p5MRDuTUgCmgCxheQWqquRmn+VPDOcefKiuTsVhGGbk8xORtQTH01Mi7U81nf4U1xzrSlr7HGuFVxsydd6nuW+q8p2u/Ax2AmpMplx5a13vvSceCE52vG/sjZ6qn/jPWaeLum3pwquONBBt4HPR/UBa/0FHL/SjB60pPUkhkBUUlXV3gx4gvQsthfMFVUZ7BigJljmKEWfeOgqiHTe7ybPDARDw80ntIV22unO0ilAcxom5aIGX7j27w3OGbBsTB09NvdVKoGpKDIirFCAJUehxJAAu/KTjCBlx+gHh4fIWR94n0Ii73UfNnEIF7Zi95gI8blaEpvDQAeo5wqeMeniJD0+gGY+zRTgtB1c0GpyhnK6gYbVuGHRvPapK1AX1jXfbDL1T5XFZqnRs2AWycXM/nbR6zoFxOEYS/pY=</wsse:BinarySecurityToken><ds:Signature Id="SIG-2D07B42FEB1F8D2BF3170721839204390" xmlns:ds="http://www.w3.org/2000/09/xmldsig#"><ds:SignedInfo><ds:CanonicalizationMethod Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"><ec:InclusiveNamespaces PrefixList="dgi soapenv" xmlns:ec="http://www.w3.org/2001/10/xml-exc-c14n#"/></ds:CanonicalizationMethod><ds:SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/><ds:Reference URI="#id-2D07B42FEB1F8D2BF3170721839203789"><ds:Transforms><ds:Transform Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"><ec:InclusiveNamespaces PrefixList="dgi" xmlns:ec="http://www.w3.org/2001/10/xml-exc-c14n#"/></ds:Transform></ds:Transforms><ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/><ds:DigestValue>aGYN5LN46Twm6UV0juNcv615hC2eAmNLnmUGuNoPOWk=</ds:DigestValue></ds:Reference></ds:SignedInfo><ds:SignatureValue>QwNXxu6MtUIPbIZhMc0w30WLeCjqB2pqujDaI1QV6ijk0eZWIeMBAiZFBg54jrAv2cOP56fjbo/Y0S1jRU47coUVCLsKEGm1e4g/yqt2KVcYZXpHvF2hnTi1zaR9Q+TuL36mgs19/RmK8wet1W3Le6p6NFqfzsv/CoVl2iPekentJkICYmjO6HAwL1BCmyka62ep7BXNHTAhvGO+xon5XgVbgmuBOEbIFZzmSZGrWCRG0gYuf22lMbOsl9t4KtVHTfLq2BtDV2sEaTTBShn6KezfAb9iA+jVI/gBJ3NBq/9892oaeAH1g9PttWZmxlwhK8pOkXFXbWqjBDFKBvuR5Q==</ds:SignatureValue><ds:KeyInfo Id="KI-2D07B42FEB1F8D2BF3170721839203687"><wsse:SecurityTokenReference wsse11:TokenType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509PKIPathv1" wsu:Id="STR-2D07B42FEB1F8D2BF3170721839203688" xmlns:wsse11="http://docs.oasis-open.org/wss/oasis-wss-wssecurity-secext-1.1.xsd"><wsse:Reference URI="#X509-2D07B42FEB1F8D2BF3170721839203686" ValueType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509PKIPathv1"/></wsse:SecurityTokenReference></ds:KeyInfo></ds:Signature></wsse:Security></soapenv:Header>
   <soapenv:Body wsu:Id="id-2D07B42FEB1F8D2BF3170721839203789" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
      <dgi:RUTPersonaGetEntidad.Execute>
         <dgi:Ruc>216638240017</dgi:Ruc>
      </dgi:RUTPersonaGetEntidad.Execute>
   </soapenv:Body>
</soapenv:Envelope>        
        '''

        # ruc_pepe = SOAP_REQUEST
        # ruc_pepe = ruc_pepe.replace('216638240017', self.ruc)
        # payload = SOAP_REQUEST.replace('REPLACEME', self.ruc)
        ipdb.set_trace()
        try:
            response = requests.request("POST", full_url, headers=headers, data=payload)
            response = requests.request("POST", full_url, headers=headers, data=ruc_pepe)
            response = requests.request("POST", full_url, headers=headers, data=SOAP_REQUEST)
            response = requests.request("POST", full_url, headers=headers, data=ENV_SOAP_REQUEST)
            self.result = response.text
        except Exception as error:
            raise ValidationError(f'Erro al firmar {error}')
        _logger.info(response)




