# -*- coding: utf-8 -*-
# from odoo import http


# class ConsultaRut(http.Controller):
#     @http.route('/consulta_rut/consulta_rut', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/consulta_rut/consulta_rut/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('consulta_rut.listing', {
#             'root': '/consulta_rut/consulta_rut',
#             'objects': http.request.env['consulta_rut.consulta_rut'].search([]),
#         })

#     @http.route('/consulta_rut/consulta_rut/objects/<model("consulta_rut.consulta_rut"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('consulta_rut.object', {
#             'object': obj
#         })

